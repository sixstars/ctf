/*
 * main.c
 * Copyright (C) 2018 hzshang <hzshang15@gmail.com>
 *
 * Distributed under terms of the MIT license.
 */

#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]){
    srand(time(0));
    fprintf(stderr,"are you admin\n");
    fflush(stdout);
    int tmp=rand();
    char name[0x30];
    fgets(name,0x30,stdin);
    atoi(name);
    printf("%d\n",tmp);
    return 0;
}
