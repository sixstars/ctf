#!/usr/bin/env python
# encoding: utf-8

import sys
    
N = 32

try:
    from key import table, num
except:
    table=[i for i in xrange(N)]
    num = 9

table1=[table.index(i) for i in range(len(table))]

alp = [ord('a')+i for i in range(26)] + [0x3a, 0x22, 0x20, 0x2c, 0x2e, 0x27]
alp1 = [(i not in alp) and 0xff or alp.index(i) for i in range(256)]

def encrypt(p):
    global table,alp,alp1,num

    p = p.replace('\r', '').replace('\n', '')
    p = [ord(x) for x in p]

    plen = len(p)
    c=[0 for i in xrange(plen)]
    for i in xrange(plen):
        if p[i]<0x60 and p[i]>0x3f:
            p[i]^=0x20
        c[i]=(alp1[p[i]]+i*num)%32
        c[i]=table[c[i]]
        c[i]=alp[c[i]]

    c1 = [chr(x) for x in c]
    return "".join(c1)

def decrypt(c):
    global table,alp,alp1,num
    
    c = [ord(x) for x in c]

    clen = len(c)
    p1=[0 for i in xrange(clen)]
    for i in xrange(clen):
        p1[i]=alp1[c[i]]
        p1[i]=table1[p1[i]]
        p1[i]=(p1[i]+i*(32-num))%32
        p1[i]=alp[p1[i]]

    p1= [chr(x) for x in p1]
    return "".join(p1)

if __name__ == '__main__':
    usage = 'usage: %s enc|dec input.txt' % sys.argv[0]
    if len(sys.argv) < 3:
        print usage
        sys.exit()

    if sys.argv[1] == 'enc':
        f = open(sys.argv[2] + '.encrypted', 'w')
        encrypted = encrypt(open(sys.argv[2]).read())
        f.write(encrypted)
        f.close()
    elif sys.argv[1] == 'dec':
        f = open(sys.argv[2] + '.decrypted', 'w')
        decrypted = decrypt(open(sys.argv[2]).read())
        f.write(decrypted)
        f.close()
    else:
        print usage
